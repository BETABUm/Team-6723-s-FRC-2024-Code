package frc.robot.subsystems;

import edu.wpi.first.wpilibj2.command.SubsystemBase;
//import com.ctre.phoenix.motorcontrol.can.TalonSRX;
//import com.ctre.phoenix.motorcontrol.can.WPI_TalonSRX;
import edu.wpi.first.wpilibj.drive.DifferentialDrive;
import edu.wpi.first.wpilibj.Joystick;
import edu.wpi.first.wpilibj.XboxController;
import frc.robot.RobotMap;
import frc.robot.commands.*;

public class drivetrain extends SubsystemBase{

    public drivetrain() {
        //kungstructor
    }

    public void init() {

    }

    public void doMecanumDrive(XboxController xbox) {

        // 2/17/2024 - based xbox axes off Mr. Louis' vex robots, however this order may not be correct for FRC and may need further adjusting

        RobotMap.RobotDrive.driveCartesian(xbox.getRightX(), xbox.getLeftY(), xbox.getLeftX());
        //RobotMap.RobotDrive.driveCartesian(0, xbox.getLeftY(), 0);
        // the middle value is the turn

        // first value makes all 4 motors go the same way
    }

    public void run(double leftspeed, double rightspeed) {
        RobotMap.left.set(leftspeed);
        RobotMap.right.set(-rightspeed);
    }

    public void stop() {
        RobotMap.left.set(0);
        RobotMap.right.set(0);
    }

    public void doMecanumDrive (double x, double y, double z) {
        RobotMap.RobotDrive.driveCartesian(x, y, z);
    }
    
}
